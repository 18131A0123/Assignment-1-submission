C=float(input())
F=(C*9/5)+32
print('%.f' % (F))
